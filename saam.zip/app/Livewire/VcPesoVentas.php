<?php

namespace App\Livewire;

use Livewire\Component;

class VcPesoVentas extends Component
{
    public function render()
    {
        return view('livewire.vc-peso-ventas');
    }
}
