<?php

namespace App\Livewire;
use App\Models\TmPersonas;
use Livewire\Component;
use Illuminate\Support\Facades\Http;

class VcMarcaciones extends Component
{
    public $fecha, $tblrecords=[];

    public function mount() {
        $ldate = date('Y-m-d H:i:s');
        $this->fecha = date('Y-m-d',strtotime($ldate));

        $this->add();
    }

    public function render()
    {
        $response = Http::withHeaders([
            'X-API-KEY' => env('LOCAL_SYNC_API_KEY'),
        ])->timeout(30)
        ->get('http://181.198.111.178/api-erp/api/leer-marcaciones');

        if ($response->failed()) {
            dd($response->status(), $response->body());
        }

        dd($response->json());

        return view('livewire.vc-marcaciones');
    }

    public function add(){
        
        $this->personas = TmPersonas::query()
        ->join("tm_contratos as c","c.persona_id","=","tm_personas.id")
        ->where('tipoempleado_id',8)
        ->where('tipocontrato_id',13)
        ->where('c.estado','A')
        ->orderBy('tm_personas.apellidos','asc')
        ->get();
        
        $campo="";
        $this->totpersona = count($this->personas);

        foreach ($this->personas as $fila => $data){
        
            $recno = [
                'linea'  => $fila+1,
                'nombre' => $data->apellidos.' '.$data->nombres,
                'nui' => $data->nui,
                'depart' => "",
                'cargo'  => "",
                'fecha' => "",
                'entrada' => "",
                'timbre1' => "",
                'salalim' => "", 
                'timbre2' => "",
                'entalim' => "",
                'timbre3' => "",
                'salida'  => "",
                'hora'    => "",
            ];
            array_push($this->tblrecords,$recno);
        }
       
       

        //dd($this->tblrecords);
        /*$this->row = [$campo];
               
        foreach ($this-> personas as $index => $data)
        {
            $this->tblrecords[$index][0] = $data->persona_id;
            $this->tblrecords[$index][1] = $data->nui;
            $this->tblrecords[$index][2] = $data->apellidos.' '.$data->nombres;

            for ($columna=0;$columna<count($this->rubros)+3;$columna++){
                if ($columna>=3) {
                    $this->tblrecords[$index][$columna] = 0.00;
                    $this->row[$columna] = 0.00;
                }
            }
            
        }

        $this->row[0] = "";
        $this->row[1] = "";
        $this->row[2] = "";*/
        
    }


}
