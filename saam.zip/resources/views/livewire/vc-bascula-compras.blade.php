<div>
    <div class="row" wire:poll.5s>
        <div class="col-lg-12">
            <!--<div class="row">
                <div class="col-xxl-3 col-sm-6">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Total Compras</font></font></p>
                                    <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="547"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">547</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Tm</font></font></h2>
                                    <p class="mb-0 text-muted"><span class="badge bg-light text-success mb-0"> <i class="ri-arrow-up-line align-middle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">17,32 %</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">vs. mes anterior</font></font></p>
                                </div>
                                <div>
                                    <div class="avatar-sm flex-shrink-0">
                                        <span class="avatar-title bg-light text-info rounded-circle fs-4">
                                            <i class="ri-ticket-2-line"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
                
                <div class="col-xxl-3 col-sm-6">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tickets Automaticos</font></font></p>
                                    <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="124"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">124</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> mil</font></font></h2>
                                    <p class="mb-0 text-muted"><span class="badge bg-light text-danger mb-0"> <i class="ri-arrow-down-line align-middle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0,96 %</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">vs. mes anterior</font></font></p>
                                </div>
                                <div>
                                    <div class="avatar-sm flex-shrink-0">
                                        <span class="avatar-title bg-light text-info rounded-circle fs-4">
                                            <i class="mdi mdi-timer-sand"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xxl-3 col-sm-6">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tikets Manuales</font></font></p>
                                    <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="107"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">107</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> mil</font></font></h2>
                                    <p class="mb-0 text-muted"><span class="badge bg-light text-danger mb-0"> <i class="ri-arrow-down-line align-middle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3,87 %</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">vs. mes anterior</font></font></p>
                                </div>
                                <div>
                                    <div class="avatar-sm flex-shrink-0">
                                        <span class="avatar-title bg-light text-info rounded-circle fs-4">
                                            <i class="ri-shopping-bag-line"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xxl-3 col-sm-6">
                    <div class="card card-animate">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <p class="fw-medium text-muted mb-0"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Tickets Anulados</font></font></p>
                                    <h2 class="mt-4 ff-secondary fw-semibold"><span class="counter-value" data-target="15.95"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">15,95</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> %</font></font></h2>
                                    <p class="mb-0 text-muted"><span class="badge bg-light text-success mb-0"> <i class="ri-arrow-up-line align-middle"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1,09 %</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">vs. mes anterior</font></font></p>
                                </div>
                                <div>
                                    <div class="avatar-sm flex-shrink-0">
                                        <span class="avatar-title bg-light text-info rounded-circle fs-4">
                                            <i class="ri-delete-bin-line"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>-->
            <div class="card" id="orderList">
                <div class="card-header border-0">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0 flex-grow-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Pesos Realizados</font></font></h5>
                        <div class="flex-shrink-0">
                            <div class="d-flex flex-wrap gap-2">
                                <a href="/bascula-compra/peso-bruto" class="btn btn-danger add-btn" target="_blank"><i class="ri-add-line align-bottom me-1"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Crear tickets</font></font></a>
                                <button class="btn btn-soft-danger" id="remove-actions" onclick="deleteMultiple()"><i class="ri-delete-bin-2-line"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <!--<div class="card-header  border-0">
                    <div class="d-flex align-items-center">
                        <h5 class="card-title mb-0 flex-grow-1">Entradas</h5>
                        <div class="flex-shrink-0">
                            <button type="button" class="btn btn-success add-btn" data-bs-toggle="modal"
                                id="create-btn" data-bs-target="#showModal"><i
                                    class="ri-add-line align-bottom me-1"></i> Create
                                Order</button>
                            <button type="button" class="btn btn-info"><i
                                    class="ri-file-download-line align-bottom me-1"></i> Import</button>
                            <button class="btn btn-soft-danger" onClick="deleteMultiple()"><i
                                    class="ri-delete-bin-2-line"></i></button>
                        </div>
                    </div>
                </div>-->
                <div class="card-body border border-dashed border-end-0 border-start-0">
                    <form>
                        <div class="row g-3">
                            <div class="col-xxl-5 col-sm-6">
                                <div class="search-box">
                                    <input type="text" class="form-control search"
                                        placeholder="Buscar por número de ticket, proveedor..." wire:model.live.debounce.300ms="filters.buscar">
                                    <i class="ri-search-line search-icon"></i>
                                </div>
                            </div>
                            <div class="col-xxl-2 col-sm-6">
                                <div>
                                    <select class="form-select" data-choices data-choices-search-false
                                        name="choices-single-default" id="idStatus" wire:model="filters.periodo">
                                        <option value="" selected>Todos</option>
                                        @foreach($periodos as $key => $valor)
                                        <option value="{{$valor->periodo}}">{{$valor->periodo}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                             <div class="col-xxl-2 col-sm-6">
                                <div>
                                    <select class="form-select" data-choices data-choices-search-false
                                        name="choices-single-default" id="idStatus" wire:model="filters.mes">
                                        <option value="" selected>Todos</option>
                                        @foreach($meses as $key => $vmes)
                                        <option value="{{$key}}">{{$vmes}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>                           
                            <div class="col-xxl-2 col-sm-4">
                                <div>
                                    <select class="form-select" data-choices data-choices-search-false
                                        name="choices-single-default" id="idStatus" wire:model="filters.sucursal">
                                        <option value="" selected>Todos</option>
                                        @foreach($sucursal as $key => $sucursal)
                                        <option value="{{$key}}">{{$sucursal}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <!--end col-->
                            <div class="col-xxl-1 col-sm-4">
                                <div>
                                    <button type="button" class="btn btn-primary w-100"
                                        onclick="SearchData();"> <i
                                            class="ri-equalizer-fill me-1 align-bottom"></i>
                                        Filtrar
                                    </button>
                                </div>
                            </div>
                            <!--end col-->
                        </div>
                        <!--end row-->
                    </form>
                </div>
                <div class="card-body pt-0">
                    <div>
                        <ul class="nav nav-tabs nav-tabs-custom nav-success mb-3" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link {{$activeTab[1]}} All py-3" data-bs-toggle="tab" id="All"
                                    href="#" onclick="Livewire.dispatch('selectTab', {tab: 1})" role="tab" aria-selected="true">
                                    <i class="ri-store-2-fill me-1 align-bottom"></i> Todos
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link py-3 {{$activeTab[2]}} Delivered" data-bs-toggle="tab" id="Delivered"
                                    href="#" onclick="Livewire.dispatch('selectTab', {tab: 2})"  role="tab" aria-selected="false">
                                    <i class="ri-checkbox-circle-line me-1 align-bottom"></i> Manuales
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link py-3 {{$activeTab[3]}} Pickups" data-bs-toggle="tab" id="Pickups"
                                    href="#" onclick="Livewire.dispatch('selectTab', {tab: 3})"  role="tab" aria-selected="false">
                                    <i class="ri-truck-line me-1 align-bottom"></i> En Patio <span
                                        class="badge bg-danger align-middle ms-1">{{$cantidad}}</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link py-3 {{$activeTab[4]}} Returns" data-bs-toggle="tab" id="Returns"
                                    href="#" onclick="Livewire.dispatch('selectTab', {tab: 4})" role="tab" aria-selected="false">
                                    <i class="ri-arrow-left-right-fill me-1 align-bottom"></i> Anulados
                                </a>
                            </li>
                        </ul>

                        <div class="table-responsive table-card mb-1">
                            <table class="table table-nowrap table-sm align-middle" id="orderTable">
                                <thead class="text-muted table-light">
                                    <tr class="text-uppercase">
                                        <th>Order ID</th>
                                        <th>Sucursal</th>
                                        <th>Proveedor</th>
                                        <th>Hacienda</th>
                                        <th>Fecha</th>
                                        <th class="text-end">Peso Tara</th>
                                        <th class="text-end">Peso Bruto</th>
                                        <th class="text-end">Peso Neto</th>
                                        <th>Chofer</th>
                                        <th>Placa</th>
                                        <th>Proceso</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="list form-check-all">
                                    @foreach($tblrecords as $record)
                                    <tr>
                                        <td class="id"><a href="apps-ecommerce-order-details"
                                                class="fw-medium link-primary">{{$record->Id_Fila}}</a></td>
                                        <td class="customer_name">{{$this->sucursal[$record->Numcia]}}</td>
                                        <td class="product_name">{{$record->proveedor}}</td>
                                        <td class="product_name">{{$record->hacienda}}</td>
                                        @if ($record->Peso_Neto==0)
                                        <td class="date">{{ \Carbon\Carbon::parse($record->Fecha_Ingreso)->format('d M, Y') }}, <small class="text-muted">{{ \Carbon\Carbon::parse($record->Hora_Ingreso)->format('h:i:s A') }}</small></td>
                                        @else
                                        <td class="date">{{ \Carbon\Carbon::parse($record->Fecha_Salida)->format('d M, Y') }}, <small class="text-muted">{{ \Carbon\Carbon::parse($record->Hora_Salida)->format('h:i:s A') }}</small></td>
                                        @endif
                                        <td class="amount text-end">{{number_format($record->Peso_Ingreso,2)}}</td>
                                        <td class="payment text-end">{{number_format($record->Peso_Salida,2)}}</td>
                                        <td class="payment text-end">{{number_format($record->Peso_Neto,2)}}</td>
                                        <td>{{$record->chofer}}</td>
                                        <td>{{$record->Placa}}</td>
                                        <td class="status"><span
                                                class="badge badge-soft-warning text-uppercase">{{$record->Proceso}}</span>
                                        </td>
                                        <td>
                                            <ul class="list-inline hstack gap-2 mb-0">
                                                <li class="list-inline-item" data-bs-toggle="tooltip"
                                                    data-bs-trigger="hover" data-bs-placement="top"
                                                    title="Imprimir">
                                                    <button onclick="window.open('{{ route('ticketCompra.pdf', $record->Id_Fila) }}', '_blank')"
                                                            class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle"><i class="ri-printer-fill fs-16"></i>
                                                    </button>
                                                </li>
                                                <li class="list-inline-item" data-bs-toggle="tooltip"
                                                    data-bs-trigger="hover" data-bs-placement="top"
                                                    title="View">
                                                    <a href="apps-ecommerce-order-details"
                                                        class="text-primary d-inline-block">
                                                        <i class="ri-eye-fill fs-16"></i>
                                                    </a>
                                                </li>
                                                @if ($record->Peso_Neto==0)
                                                <li class="list-inline-item" data-bs-toggle="tooltip"
                                                    data-bs-trigger="hover" data-bs-placement="top"
                                                    title="Editar">
                                                    <a href="/bascula-compra/peso-tara/{{$record->Id_Fila}}"
                                                        class="text-primary d-inline-block" target="_blank">
                                                        <i class="ri-pencil-fill fs-16"></i>
                                                    </a>
                                                </li>
                                                @endif
                                                <li class="list-inline-item" data-bs-toggle="tooltip"
                                                    data-bs-trigger="hover" data-bs-placement="top"
                                                    title="Remove">
                                                    <a class="text-danger d-inline-block remove-item-btn"
                                                        data-bs-toggle="modal" href="#deleteOrder">
                                                        <i class="ri-delete-bin-5-fill fs-16"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div class="noresult" style="display: none">
                                <div class="text-center">
                                    <lord-icon src="https://cdn.lordicon.com/msoeawqm.json"
                                        trigger="loop" colors="primary:#405189,secondary:#0ab39c"
                                        style="width:75px;height:75px">
                                    </lord-icon>
                                    <h5 class="mt-2">Sorry! No Result Found</h5>
                                    <p class="text-muted">We've searched more than 150+ Orders We did
                                        not find any
                                        orders for you search.</p>
                                </div>
                            </div>
                        </div>
                        <!--<div class="d-flex justify-content-end">
                            <div class="pagination-wrap hstack gap-2">
                                <a class="page-item pagination-prev disabled" href="#">
                                    Previous
                                </a>
                                <ul class="pagination listjs-pagination mb-0"></ul>
                                <a class="page-item pagination-next" href="#">
                                    Next
                                </a>
                            </div>
                        </div>-->
                        {{$tblrecords->links('')}}
                    </div>
                    <div wire.ignore.self class="modal fade" id="showModal" tabindex="-1"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header bg-light p-3">
                                    <h5 class="modal-title" id="exampleModalLabel">&nbsp;</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close" id="close-modal"></button>
                                </div>
                                <form action="#">
                                    <div class="modal-body">
                                        <input type="hidden" id="id-field" />

                                        <div class="mb-3" id="modal-id">
                                            <label for="orderId" class="form-label">ID</label>
                                            <input type="text" id="orderId" class="form-control"
                                                placeholder="ID" readonly />
                                        </div>

                                        <div class="mb-3">
                                            <label for="customername-field" class="form-label">Customer
                                                Name</label>
                                            <input type="text" id="customername-field"
                                                class="form-control" placeholder="Enter name"
                                                required />
                                        </div>

                                        <div class="mb-3">
                                            <label for="productname-field"
                                                class="form-label">Product</label>
                                            <select class="form-control" data-trigger
                                                name="productname-field" id="productname-field">
                                                <option value="">Product</option>
                                                <option value="Puma Tshirt">Puma Tshirt</option>
                                                <option value="Adidas Sneakers">Adidas Sneakers</option>
                                                <option value="350 ml Glass Grocery Container">350 ml
                                                    Glass Grocery Container</option>
                                                <option value="American egale outfitters Shirt">American
                                                    egale outfitters Shirt</option>
                                                <option value="Galaxy Watch4">Galaxy Watch4</option>
                                                <option value="Apple iPhone 12">Apple iPhone 12</option>
                                                <option value="Funky Prints T-shirt">Funky Prints
                                                    T-shirt</option>
                                                <option
                                                    value="USB Flash Drive Personalized with 3D Print">
                                                    USB Flash Drive Personalized with 3D Print</option>
                                                <option value="Oxford Button-Down Shirt">Oxford
                                                    Button-Down Shirt</option>
                                                <option value="Classic Short Sleeve Shirt">Classic Short
                                                    Sleeve Shirt</option>
                                                <option value="Half Sleeve T-Shirts (Blue)">Half Sleeve
                                                    T-Shirts (Blue)</option>
                                                <option value="Noise Evolve Smartwatch">Noise Evolve
                                                    Smartwatch</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="date-field" class="form-label">Order
                                                Date</label>
                                            <input type="date" id="date-field" class="form-control"
                                                data-provider="flatpickr" data-date-format="d M, Y"
                                                data-enable-time required placeholder="Select date" />
                                        </div>

                                        <div class="row gy-4 mb-3">
                                            <div class="col-md-6">
                                                <div>
                                                    <label for="amount-field"
                                                        class="form-label">Amount</label>
                                                    <input type="text" id="amount-field"
                                                        class="form-control" placeholder="Total amount"
                                                        required />
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div>
                                                    <label for="payment-field"
                                                        class="form-label">Payment
                                                        Method</label>
                                                    <select class="form-control" data-trigger
                                                        name="payment-method" id="payment-field">
                                                        <option value="">Payment Method</option>
                                                        <option value="Mastercard">Mastercard</option>
                                                        <option value="Visa">Visa</option>
                                                        <option value="COD">COD</option>
                                                        <option value="Paypal">Paypal</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div>
                                            <label for="delivered-status" class="form-label">Delivery
                                                Status</label>
                                            <select class="form-control" data-trigger
                                                name="delivered-status" id="delivered-status">
                                                <option value="">Delivery Status</option>
                                                <option value="Pending">Pending</option>
                                                <option value="Inprogress">Inprogress</option>
                                                <option value="Cancelled">Cancelled</option>
                                                <option value="Pickups">Pickups</option>
                                                <option value="Delivered">Delivered</option>
                                                <option value="Returns">Returns</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <div class="hstack gap-2 justify-content-end">
                                            <button type="button" class="btn btn-light"
                                                data-bs-dismiss="modal">Close</button>
                                            <button type="submit" class="btn btn-success"
                                                id="add-btn">Add Order</button>
                                            <button type="button" class="btn btn-success"
                                                id="edit-btn">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade flip" id="deleteOrder" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-body p-5 text-center">
                                    <lord-icon src="https://cdn.lordicon.com/gsqxdxog.json"
                                        trigger="loop" colors="primary:#405189,secondary:#f06548"
                                        style="width:90px;height:90px"></lord-icon>
                                    <div class="mt-4 text-center">
                                        <h4>You are about to delete a order ?</h4>
                                        <p class="text-muted fs-15 mb-4">Deleting your order will remove
                                            all of
                                            your information from our database.</p>
                                        <div class="hstack gap-2 justify-content-center remove">
                                            <button
                                                class="btn btn-link link-success fw-medium text-decoration-none"
                                                data-bs-dismiss="modal"><i
                                                    class="ri-close-line me-1 align-middle"></i>
                                                Close</button>
                                            <button class="btn btn-danger" id="delete-record">Yes,
                                                Delete It</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end modal -->
                </div>
            </div>

        </div>
        <!--end col-->
    </div>
    <!--end row-->
</div>
