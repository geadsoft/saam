<div>
    <form id="addrubro-form" autocomplete="off" class="needs-validation" wire:submit.prevent="createData()">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label for="cmbtiporol" class="form-label">Emisión</label>
                            <div>
                                <input id="dfechaini" name="dateIni" type="date" class="form-control" data-provider="flatpickr" data-date-format="d-m-Y" data-time="true" wire:model.defer="fecha" required>
                            </div>
                        </div>                        
                        <div class="col-md-auto ms-auto">
                            <div class="hstack text-nowrap gap-2">
                                <button type="button" wire:click.prevent="add()" class="btn btn-danger add-btn" data-bs-toggle="modal" id="create-btn"
                                    data-bs-target=""><i class="ri-file-copy-fill align-bottom me-1"></i> Calcular Horas
                                </button>
                                <button type="sumit" class="btn btn-success add-btn" data-bs-toggle="modal" id="create-btn"
                                    data-bs-target=""><i class="ri-save-3-fill align-bottom me-1"></i> Grabar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
        <div class="col-xxl-12">
            <div class="card" id="contactList">
                <div class="card-header">
                    
                </div>
                <div class="card-body">
                    <div>
                        <div class="table-responsive table-card mb-3">
                            <div style="overflow-x:auto;">
                            <table class="table table-nowrap align-middle" style="width:100%">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col" style="width: 50px;">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox"
                                                    id="checkAll" value="option">
                                            </div>
                                        </th>
                                        <!--<th class="sort" data-sort="id" scope="col">ID</th>-->
                                        <th scope="col" style="display:none">Id</th>
                                        <th scope="col">Nui</th>
                                        <th scope="col">Nombre</th>
                                        <th scope="col">Departamento</th> 
                                        <th scope="col">Cargo</th>
                                        <th scope="col">Fecha</th>
                                        <th scope="col">Entrada</th>
                                        <th scope="col">Timbre</th>
                                        <th scope="col">Sal Alim</th>
                                        <th scope="col">Timbre</th>
                                        <th scope="col">Ent Alim</th>
                                        <th scope="col">Timbre</th>
                                        <th scope="col">Salida</th>
                                        <th scope="col">Timbre</th>
                                    </tr>
                                </thead>
                                <tbody class="list form-check-all">
                                    @foreach ($tblrecords as $fil => $data)
                                        <tr id="{{$fil}}" class="detalle">
                                            <th scope="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="chk_child"
                                                        value="option1">
                                                </div>
                                            </th>
                                            <td>
                                            <input type="text" style="width:100px" class="form-control form-control-sm product-price" id="nui-{{$fil}}" 
                                            wire:model="tblrecords.[$fil].[nui]"/>
                                            </td>
                                            <td>
                                            <input type="text" class="form-control form-control-sm" id="nombre-{{$fil}}" 
                                            wire:model="tblrecords.{{$fil}}.['nombre']"/>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            </div>
                        </div>                 
                    </div>
                </div>
            </div>
            <!--end card-->
        </div>
        <!--end col-->
        
        <!--end col-->
    </div>
    <!--end row-->
    </form>
</div>

