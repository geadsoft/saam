<div>
    <div class="mb-3">
        <label for="codigo" class="form-label">Código</label>
        <input type="text" value="{{$codigo}}" class="form-control" name="codigo"
            placeholder="Enter name" required />
    </div>
</div>
