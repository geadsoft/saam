<?php
    return [
        "N" => "Nuevo",
        "P" => "En Progreso",
        "F" => "Finalizado",
        "A" => "Abierto",
        "M" => "Mantenimiento",
        "S" => "Soporte",
        "C" => "Corrección",
        "R" => "Reporte",
        "E" => "Errores Sistema",
        "W" => "Cambios Sistema",
    ]
?>
